from distutils.core import setup

setup(
    name="pyanalysis",
    version="1.0",
    author="strengthening",
    author_email="strengthen2010@gmail.com",
    # url='http://www.you.com/projectname',
    packages=["pyanalysis", "pyanalysis.database", "pyanalysis.log"],
)
